sequence = raw_input().strip()
rna=""
complement=""

for x in sequence:
	if(x=="A"):
		complement=complement+"T"
	elif(x=="T"):
		complement=complement+"A"
	elif(x=="C"):
		complement=complement+"G"
	elif(x=="G"):
		complement=complement+"C"

for i in complement:
	if(i=="A"):
		rna=rna+"U"
	elif(i=="T"):
		rna=rna+"A"
	elif(i=="G"):
		rna=rna+"C"
	elif(i=="C"):
		rna=rna+"G"
		
print rna

#Or simplier/straightforward:

# sequence = raw_input().strip()
# rna=""

# for i in sequence:
# 	if(i=="T"):
# 		rna=rna+"U"
# 	elif(i=="A" or i=="C" or i=="G"):
# 		rna=rna+i
# 	else:
# 		print"Invalid input"
		
# print rna