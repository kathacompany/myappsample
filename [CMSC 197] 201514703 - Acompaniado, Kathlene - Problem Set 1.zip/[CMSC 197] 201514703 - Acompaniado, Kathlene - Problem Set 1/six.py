from textwrap import wrap
sequence = raw_input().strip()
protein = ""

dna = wrap(sequence,3)

for i in dna:
	if (i=="UUU" or i=="UUC"):
		protein=protein+"F"
	elif (i=="UUA" or i=="UUG" or i=="CUU" or i=="CUC" or i=="CUA" or i=="CUG"):
		protein=protein+"L"
	elif (i=="UCU" or i=="UCC" or i=="UCA" or i=="UCG" or i=="AGU" or i=="AGC"):
		protein=protein+"S"
	elif (i=="UAU" or i=="UAC"):
		protein=protein+"Y"
	
	elif (i=="UAA" or i=="UAG" or i=="UGA"):
		break;

	elif (i=="UGU" or i=="UGC"):
		protein=protein+"C"
	elif (i=="UGG"):
		protein=protein+"W"
	elif (i=="CCU" or i=="CCC" or i=="CCA" or i=="CCG"):
		protein=protein+"P"
	elif (i=="CAU" or i=="CAC"):
		protein=protein+"H"
	elif (i=="CAA" or i=="CAG"):
		protein=protein+"Q"
	elif (i=="CGU" or i=="CGC" or i=="CGA" or i=="CGG" or i=="AGA" or i=="AGG"):
		protein=protein+"R"
	elif (i=="AUU" or i=="AUC" or i=="AUA"):
		protein=protein+"I"
	elif (i=="AUG"):
		protein=protein+"M"
	elif (i=="ACU" or i=="ACC" or i=="ACA" or i=="ACG"):
		protein=protein+"T"
	elif (i=="AAU" or i=="AAC"):
		protein=protein+"N"
	elif (i=="AAA" or i=="AAG"):
		protein=protein+"K"
	elif (i=="GUU" or i=="GUC" or i=="GUA" or i=="GUG"):
		protein=protein+"V"
	elif (i=="GCU" or i=="GCC" or i=="GCA" or i=="GCG"):
		protein=protein+"A"
	elif (i=="GAU" or i=="GAC"):
		protein=protein+"D"
	elif (i=="GAA" or i=="GAG"):
		protein=protein+"E"
	elif (i=="GGU" or i=="GGC" or i=="GGA" or i=="GGG"):
		protein=protein+"G"


print protein